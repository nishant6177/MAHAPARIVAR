package com.example.kutumb.Notifications;

public class MyResponse {

    public int success;

}
