package com.example.kutumb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Original extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DatabaseReference databaseReference;
    private DrawerLayout drawerLayout;
    private BottomNavigationView bottomNavigationView;
    private Toolbar toolbar;
    private NavigationView navigationView;
    private Fragment selectorFragment;
    private FloatingActionButton fab;

    private AppBarLayout appBarLayout;

    private ImageView search;

    private TextView nav_fullname, nav_user_email, phoneNumber;
    private CircleImageView nav_user_image;
    private ImageView chatting;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_original);
        fab = findViewById(R.id.fab);
        drawerLayout = findViewById(R.id.drawerLayout);
        toolbar = findViewById(R.id.chatRoomToolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        navigationView = findViewById(R.id.navigationView);
        navigationView.setItemIconTintList(null);
        navigationView.setItemTextColor(null);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(Original.this, drawerLayout
                ,toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        navigationView.setNavigationItemSelectedListener(this);
        toggle.syncState();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Original.this, PostActivity.class);
                startActivity(intent);
            }
        });

        chatting = findViewById(R.id.chatting);
        chatting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Original.this, ChatActivity.class);
                startActivity(intent);
            }
        });

        nav_user_image = navigationView.getHeaderView(0).findViewById(R.id.nav_user_image);
        nav_fullname = navigationView.getHeaderView(0).findViewById(R.id.nav_user_fullname);
        nav_user_email = navigationView.getHeaderView(0).findViewById(R.id.nav_user_email);
        phoneNumber = navigationView.getHeaderView(0).findViewById(R.id.phonenumber);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(
                FirebaseAuth.getInstance().getCurrentUser().getUid()
        );

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    String name = snapshot.child("username").getValue().toString();
                    nav_fullname.setText(name);
                    String email = snapshot.child("email").getValue().toString();
                    nav_user_email.setText(email);
                    String phone = snapshot.child("phone").getValue().toString();
                    phoneNumber.setText(phone);

                    if (snapshot.hasChild("imageUrl")){
                        String imageUrl = snapshot.child("imageUrl").getValue().toString();
                        Glide.with(getApplicationContext()).load(imageUrl).into(nav_user_image);
                    }else {
                        nav_user_image.setImageResource(R.drawable.primary);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        appBarLayout = findViewById(R.id.chatRoomAppBarLayout);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.nav_home:
                        selectorFragment = new HomeFragment();
                        appBarLayout.setVisibility(View.VISIBLE);
                        break;
                    case R.id.nav_profile:
                        selectorFragment = new ProfileFragment();
                        bottomNavigationView.setVisibility(View.VISIBLE);
                        appBarLayout.setVisibility(View.GONE);
                        break;
                    case R.id.nav_search:
                        selectorFragment = new SearchFragment();
                        appBarLayout.setVisibility(View.GONE);
                        break;
                    case R.id.nav_like:
                        selectorFragment = new NotificationFragment();
                        appBarLayout.setVisibility(View.GONE);
                        break;
                }
                if (selectorFragment != null){
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectorFragment).commit();
                }
                return true;
            }
        });

        Bundle intent = getIntent().getExtras();
        if (intent != null){
            String profileId = intent.getString("publisherId");
            getSharedPreferences("PROFILE", MODE_PRIVATE).edit().putString("profileId", profileId).apply();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ProfileFragment()).commit();
            bottomNavigationView.setSelectedItemId(R.id.nav_profile);
            appBarLayout.setVisibility(View.GONE);
        } else {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.signOut:
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(Original.this, LOGIN.class);
                startActivity(intent);
                break;
            case R.id.games:
                Intent intent1 = new Intent(Original.this, Games.class);
                startActivity(intent1);
                break;
            case R.id.events:
                Intent intent2 = new Intent(Original.this, Calender.class);
                startActivity(intent2);
                break;
            case R.id.pro:
                Intent intent3 = new Intent(Original.this, Rituals.class);
                startActivity(intent3);
                break;
            case R.id.pay:
                Intent intent4 = new Intent(Original.this, PaymentsActivity.class);
                startActivity(intent4);
                break;
            case R.id.aplus:
                Intent intent5 = new Intent(Original.this, Emergency.class);
                startActivity(intent5);
                break;
            case R.id.location:
                Intent intent6 = new Intent(Original.this, Location.class);
                startActivity(intent6);
                break;

        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return false;
    }
}