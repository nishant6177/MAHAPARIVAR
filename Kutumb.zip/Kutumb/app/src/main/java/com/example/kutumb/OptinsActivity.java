package com.example.kutumb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class OptinsActivity extends AppCompatActivity {

    private TextView settings;
    private TextView logOut;
    private TextView Version;
    private TextView rituals;
    private TextView payments;
    private TextView Events;
    private TextView Emergency;
    private TextView location;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_optins);

        settings = findViewById(R.id.settings);
        logOut = findViewById(R.id.Logout);
        Version = findViewById(R.id.version);
        rituals = findViewById(R.id.rituals);
        payments = findViewById(R.id.payments);
        Events = findViewById(R.id.Events);
        Emergency = findViewById(R.id.Emergency);
        location = findViewById(R.id.Location);
        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OptinsActivity.this, Location.class);
                startActivity(intent);
            }
        });
        Emergency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OptinsActivity.this, Emergency.class);
                startActivity(intent);
            }
        });
        Events.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OptinsActivity.this, Calender.class);
                startActivity(intent);
            }
        });
        payments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OptinsActivity.this, PaymentsActivity.class);
                startActivity(intent);
            }
        });
        rituals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OptinsActivity.this, Rituals.class);
                startActivity(intent);
            }
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Options");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(OptinsActivity.this, LOGIN.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                finish();
            }
        });

        Version.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(OptinsActivity.this, "Version 1.0", Toast.LENGTH_SHORT).show();
            }
        });

    }
}