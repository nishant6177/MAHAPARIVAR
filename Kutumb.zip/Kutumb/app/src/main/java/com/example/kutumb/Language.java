package com.example.kutumb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class Language extends AppCompatActivity {

    Button english,hindi,marathi,gujarati,telugu,punjabi,bengali,kannada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        english=findViewById(R.id.btn_english);
        marathi=findViewById(R.id.btn_marathi);
        hindi=findViewById(R.id.btn_hindi);
        gujarati=findViewById(R.id.btn_gujarati);
        telugu=findViewById(R.id.btn_telugu);
        punjabi=findViewById(R.id.btn_punjabi);
        bengali=findViewById(R.id.btn_bengali);
        kannada=findViewById(R.id.btn_kannada);

        kannada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("kn");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
        bengali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("bn");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
        punjabi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("pa");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
        telugu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("te");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
        gujarati.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("gu");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
        marathi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("mr");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
        english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("en");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
        hindi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLanguage("hi");
                Intent intent = new Intent(Language.this, JoinCreate.class);
                startActivity(intent);
            }
        });
    }
    private void changeLanguage(String language) {
        Locale locale=new Locale(language);
        Locale.setDefault(locale);
        Configuration configuration=new Configuration();
        configuration.locale=locale;
        getBaseContext().getResources().updateConfiguration(configuration,getBaseContext().getResources().getDisplayMetrics());
    }
}