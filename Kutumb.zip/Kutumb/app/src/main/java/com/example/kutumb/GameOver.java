package com.example.kutumb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class GameOver extends AppCompatActivity {

    private Toolbar toolbar;
    TextView tvPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Back");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        tvPoints = findViewById(R.id.tvPoints);
        boolean win = getIntent().getExtras().getBoolean("win");
        if (win){
            tvPoints.setTextColor(Color.GREEN);
            tvPoints.setText("You Win. :)");
        }else {
            tvPoints.setTextColor(Color.RED);
            tvPoints.setText("You Loose. :( ");
        }
    }
    public void restart(View view){
        Intent intent =  new Intent(this, BaloonShooter.class);
        startActivity(intent);
        finish();
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}