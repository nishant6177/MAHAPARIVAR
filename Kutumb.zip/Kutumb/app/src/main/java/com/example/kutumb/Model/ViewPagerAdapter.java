package com.example.kutumb.Model;

public class ViewPagerAdapter {
}
