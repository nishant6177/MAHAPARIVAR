package com.example.kutumb;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

public class PaymentsActivity extends AppCompatActivity implements PaymentResultListener {

    Button btpay;
    EditText editAmount;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payments);
        editAmount = findViewById(R.id.editAmount);

        btpay = findViewById(R.id.payment);

        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btpay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPayment(Integer.parseInt(editAmount.getText().toString()));
            }
        });
    }

    private void startPayment(int Amount) {
        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_gHpXBQocuTo6eh");

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name","MahaPariVar");
            jsonObject.put("description","If you want to pay");
            jsonObject.put("theme.color","#3399cc");
            jsonObject.put("currency","INR");
            jsonObject.put("amount",Amount*100);
            JSONObject retryObj = new JSONObject();
            retryObj.put("enabled",true);
            retryObj.put("max_count",4);
            jsonObject.put("retry",retryObj);

            checkout.open(PaymentsActivity.this,jsonObject);
        } catch (Exception e){
            Toast.makeText(this, "Something went wrong!!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPaymentSuccess(String s) {
        Toast.makeText(this, "Payment Success!!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(this, "Something went wrong!!", Toast.LENGTH_SHORT).show();
    }
}