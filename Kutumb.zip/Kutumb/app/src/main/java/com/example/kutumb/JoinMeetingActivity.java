package com.example.kutumb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.jitsi.meet.sdk.BroadcastEvent;
import org.jitsi.meet.sdk.JitsiMeet;
import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import org.jitsi.meet.sdk.JitsiMeetUserInfo;


import java.net.MalformedURLException;
import java.net.URL;

import timber.log.Timber;

public class JoinMeetingActivity extends AppCompatActivity {

    EditText edtName, edtChannelName;
    Button btnJoin;

    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver(){
        @Override
        public void onReceive(Context context, Intent intent) {
            onBroadcastReceived(intent);
        }
    };


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_meeting);

        edtName = findViewById(R.id.edt_name);
        edtChannelName = findViewById(R.id.edt_channel);
        btnJoin = findViewById(R.id.btn_joined);

        URL serverURL;
        try {
            serverURL = new URL("https://meet.jit.si");
        } catch (MalformedURLException e){
            e.printStackTrace();
            throw new RuntimeException("Invalid Server URL!");
        }


        JitsiMeetUserInfo userInfo = new JitsiMeetUserInfo();
        userInfo.setDisplayName(edtName.getText().toString());
        JitsiMeetConferenceOptions defaultOptions
                = new JitsiMeetConferenceOptions.Builder()
                .setServerURL(serverURL)
                .setUserInfo(userInfo)
                .build();
        JitsiMeet.setDefaultConferenceOptions(defaultOptions);

        registerForBroadcastMessages();


        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (! TextUtils.isEmpty(edtName.getText().toString()) && ! TextUtils.isEmpty(edtChannelName.getText().toString())){
                    joinMeeting(edtName.getText().toString(), edtChannelName.getText().toString());
                }
            }
        });
    }

    private void registerForBroadcastMessages() {

        IntentFilter intentFilter = new IntentFilter();
        for (BroadcastEvent.Type type : BroadcastEvent.Type.values()){
            intentFilter.addAction(type.getAction());
        }

        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, intentFilter);

    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
        super.onDestroy();
    }

    private void joinMeeting(String name, String channel) {
        JitsiMeetConferenceOptions options
                = new JitsiMeetConferenceOptions.Builder()
                .setRoom(channel)
                .build();
        JitsiMeetActivity.launch(JoinMeetingActivity.this, options);
    }

    private void onBroadcastReceived(Intent intent){
        if (intent != null){
            BroadcastEvent event = new BroadcastEvent(intent);
            switch (event.getType()){
                case CONFERENCE_JOINED:
                    Timber.i("Conference Joined with url%s", event.getData().get("url"));
                    break;
                case PARTICIPANT_JOINED:
                    Timber.i("Participant joined%s", event.getData().get("url"));
                    break;
            }
        }
    }

    public void back(View view) {
        finish();
    }

}