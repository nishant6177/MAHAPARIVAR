package com.example.kutumb;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Rituals extends AppCompatActivity {

    private ImageView back;
    Dialog myDialog;
    LinearLayout hindu, islamic, sikhism, jainism, buddhism, christianity;
    private Button more;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rituals);

        back = findViewById(R.id.back);
        myDialog = new Dialog(this);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        sikhism = findViewById(R.id.sikh);
        sikhism.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView close;
                myDialog.setContentView(R.layout.sikhism);
                close = (ImageView) myDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });

        islamic = findViewById(R.id.islamic);
        islamic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView close;
                myDialog.setContentView(R.layout.islamic);
                close = (ImageView) myDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });

        hindu = findViewById(R.id.hindu);
        hindu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView close;
                myDialog.setContentView(R.layout.hindu);
                close = (ImageView) myDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });

        jainism = findViewById(R.id.jain);
        jainism.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView close;
                myDialog.setContentView(R.layout.jainism);
                close = (ImageView) myDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });

        buddhism = findViewById(R.id.budh);
        buddhism.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView close;
                myDialog.setContentView(R.layout.buddhism);
                close = (ImageView) myDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });

        christianity = findViewById(R.id.christ);
        christianity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView close;
                myDialog.setContentView(R.layout.christianity);
                close = (ImageView) myDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });

        more = findViewById(R.id.more);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView close;
                TextView l1, l2, l3, l4, l5, l6;
                myDialog.setContentView(R.layout.information);
                close = (ImageView) myDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                l1 = (TextView) myDialog.findViewById(R.id.l1);
                l1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("https://www.britannica.com/topic/Hinduism");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                });

                l2 = (TextView) myDialog.findViewById(R.id.l2);
                l2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("https://www.britannica.com/topic/Islam");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                });

                l3 = (TextView) myDialog.findViewById(R.id.l3);
                l3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("https://www.britannica.com/topic/Sikhism");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                });

                l4 = (TextView) myDialog.findViewById(R.id.l4);
                l4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("https://www.britannica.com/topic/Jainism");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                });

                l5 = (TextView) myDialog.findViewById(R.id.l5);
                l5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("https://www.britannica.com/topic/Buddhism");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                });

                l6 = (TextView) myDialog.findViewById(R.id.l6);
                l6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("https://www.britannica.com/topic/Christianity");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                });

                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });
    }
}