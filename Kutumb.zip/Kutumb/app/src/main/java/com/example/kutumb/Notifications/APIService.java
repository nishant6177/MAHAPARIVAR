package com.example.kutumb.Notifications;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {
    @Headers(
            {
                    "Content-Type:applicant/json",
                    "Authorization:key=AAAAsZBWrOs:APA91bHL2PJZbSzUUhvt5zjLU1ASVXV4DwCPdOdi9XGuk16pjXpKGscENxLLz7RKmSdgTBzWAPnQlB960NItnfwN3UMJOJ8gBoSvfsLTJUtN6qKcUg4CAmyDOwzYwJ-0SKNEMJpA410M"
            }
    )
    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body Sender body);
}
